#ifndef __AKBI_CCU_MSG_HANDLER_H__
#define __AKBI_CCU_MSG_HANDLER_H__

void akbi_process_rx_serial_data(char *ccu_msg,int length);


#endif
